import { Routes, Route } from "react-router-dom";
import NotFound from "./pages/not-found";
import Home from "./pages/home";
import Login from "./pages/profile/login";
import Logout from "./pages/profile/logout";
import Chat from "./pages/chat";
import useLocalStorage from "use-local-storage";
import AddContact from "./pages/contacts/add";
import Contacts from "./pages/contacts";
import Chats from "./pages/chats";
import { useEffect, useState } from "react";
import { notify } from "./pages/chat/notify";

onblur = (e) => (window.roomID = "");

function App() {
  const [contacts, setContacts] = useLocalStorage(projectID + "contacts", {
    [user]: "You",
  });

  const [messages, setMessages] = useState({});
  const [chattRooms, setChattRooms] = useLocalStorage(projectID + "rooms", {});
  4;

  async function onMessageData(data) {
    var id = data?.room ?? "";
    if (!chattRooms?.[id]) {
      var name = await API.get("chat-name", id);
      setChattRooms((old) => {
        return {
          ...old,
          [id]: { name, unread: 1 },
        };
      });
    }
    //check if the actual room is focus
    if (roomID != id) {
      //add to the unread messages in room 1
      setChattRooms((old) => {
        return {
          ...old,
          [id]: {
            name: old[id].name,
            unread: old[id].unread + 1,
          },
        };
      });
      //send a notification
      notify(contacts, data);
    }
    //set the messages
    setMessages((old) => {
      return {
        ...old,
        [id]: [...(old[id] ?? []), data],
      };
    });
  }

  //if a message come
  API.onSay("incomming-message", onMessageData, true);

  API.onSay(
    "message-change",
    (data) => {
      log(data);
    },
    true
  );

  useEffect(() => {
    API.get("unread-messages").then((data) => {
      data.forEach(onMessageData);
    });
  }, []);

  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route
        path="/chats"
        element={<Chats setRooms={setChattRooms} rooms={chattRooms} />}
      />
      <Route
        path="/chat/:id"
        element={
          <Chat
            contacts={contacts}
            setContacts={setContacts}
            messages={messages}
            setMessages={setMessages}
          />
        }
      />
      <Route
        path="/contacts/add/:id"
        element={<AddContact contacts={contacts} setContacts={setContacts} />}
      />
      <Route
        path="/contacts/"
        element={
          <Contacts
            setRooms={setChattRooms}
            contacts={contacts}
            setContacts={setContacts}
          />
        }
      />
      <Route path="profile/login" element={<Login />} />
      <Route path="profile/logout" element={<Logout />} />
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
}

export default App;
