import { Routes, Route } from "react-router-dom";
import NotFound from "./pages/not-found";
import Home from "./pages/home";
import Login from "./pages/profile/login";
import Logout from "./pages/profile/logout";
import Chat from "./pages/chat";
import useLocalStorage from "use-local-storage";

function App() {
  const [contacts, setContacts] = useLocalStorage(projectID + "contacts", {});

  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route
        path="/chat/:id"
        element={<Chat contacts={contacts} setContacts={setContacts} />}
      />
      <Route path="profile/login" element={<Login />} />
      <Route path="profile/logout" element={<Logout />} />
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
}

export default App;
