import { Routes, Route } from "react-router-dom";
import NotFound from "./pages/not-found";
import Home from "./pages/home";
import Login from "./pages/profile/login";
import Logout from "./pages/profile/logout";
import Chat from "./pages/chat";
import useLocalStorage from "use-local-storage";
import AddContact from "./pages/contacts/add";
import Contacts from "./pages/contacts";
import Chats from "./pages/chats";
import { useState } from "react";

function App() {
  const [contacts, setContacts] = useLocalStorage(projectID + "contacts", {
    [user]: "You",
  });

  const [messages, setMessages] = useState({});

  //if a message come
  API.onSay(
    "incomming-message",
    (data) => {
      setMessages((old) => {
        var id = data?.room ?? "";
        return {
          ...old,
          [id]: [...old[id], data],
        };
      });
      if (Notification.permission == "granted" && data.from != user) {
        var not = new Notification(contacts[data.from] ?? data.from, {
          body: data.data,
        });
        not.addEventListener("click", (e) => {
          not.close();
          document.location.hash = `/chat/${data.room}`;
        });
      } else Notification.requestPermission();
    },
    true
  );

  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/chats" element={<Chats />} />
      <Route
        path="/chat/:id"
        element={
          <Chat
            contacts={contacts}
            setContacts={setContacts}
            messages={messages}
            setMessages={setMessages}
          />
        }
      />
      <Route
        path="/contacts/add/:id"
        element={<AddContact contacts={contacts} setContacts={setContacts} />}
      />
      <Route
        path="/contacts/"
        element={<Contacts contacts={contacts} setContacts={setContacts} />}
      />
      <Route path="profile/login" element={<Login />} />
      <Route path="profile/logout" element={<Logout />} />
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
}

export default App;
