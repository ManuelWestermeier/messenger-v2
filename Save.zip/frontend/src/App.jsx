import { Routes, Route } from "react-router-dom";
import NotFound from "./pages/not-found";
import Home from "./pages/home";
import Login from "./pages/profile/login";
import Logout from "./pages/profile/logout";
import Chat from "./pages/chat";
import useLocalStorage from "use-local-storage";
import AddContact from "./pages/contacts/add";
import Contacts from "./pages/contacts";
import Chats from "./pages/chats";
import { useEffect, useState } from "react";
import { notify } from "./pages/chat/notify";

function App() {
  const [contacts, setContacts] = useLocalStorage(projectID + "contacts", {
    [user]: "You",
  });

  const [messages, setMessages] = useState({});
  const [chattRooms, setChattRooms] = useLocalStorage(projectID + "rooms", {});

  //if a message come
  API.onSay(
    "incomming-message",
    async (data) => {
      var id = data?.room ?? "";
      if (!chattRooms?.[id]) {
        var name = await API.get("chat-name", id);
        setChattRooms((old) => {
          return {
            ...old,
            [id]: { name, unread: 1 },
          };
        });
      }
      setMessages((old) => {
        return {
          ...old,
          [id]: [...(old[id] ?? []), data],
        };
      });
      notify(contacts, data);
    },
    true
  );

  useEffect(() => {
    API.get("unread-messages").then((data) => {
      log(data);
      data.forEach((msg) => {
        notify(contacts, msg);
      });
    });
  }, []);

  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/chats" element={<Chats rooms={chattRooms} />} />
      <Route
        path="/chat/:id"
        element={
          <Chat
            contacts={contacts}
            setContacts={setContacts}
            messages={messages}
            setMessages={setMessages}
          />
        }
      />
      <Route
        path="/contacts/add/:id"
        element={<AddContact contacts={contacts} setContacts={setContacts} />}
      />
      <Route
        path="/contacts/"
        element={
          <Contacts
            setRooms={setChattRooms}
            contacts={contacts}
            setContacts={setContacts}
          />
        }
      />
      <Route path="profile/login" element={<Login />} />
      <Route path="profile/logout" element={<Logout />} />
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
}

export default App;
