import { Link } from "react-router-dom";

function Home() {
  return (
    <div className="container">
      <h1>Home</h1>
      <Link to="/chat/hallowelt">Chat</Link>
    </div>
  );
}
export default Home;
