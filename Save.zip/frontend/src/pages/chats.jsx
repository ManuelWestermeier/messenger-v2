function Chats() {
  return <div className="container">Chats</div>;
}
export default Chats;
