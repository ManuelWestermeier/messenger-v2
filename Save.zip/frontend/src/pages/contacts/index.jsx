function Contacts({ contacts, setContacts }) {
  return (
    <div className="container">
      <h3>Contacts</h3>
      <ul className="list-group list-group-flush">
        {Object.keys(contacts).map((key) => {
          <li key={key} className="list-group-item">
            <span class="badge bg-primary rounded-pill">0</span>
          </li>;
        })}
      </ul>
    </div>
  );
}
export default Contacts;
