import { useEffect, useState } from "react";
import { Link } from "react-router-dom";

function Contacts({ contacts, setContacts }) {
  const [selected, setSelected] = useState(
    Object.keys(contacts).map(() => false)
  );
  const [userType, setUserType] = useState(
    Object.keys(contacts).map(() => "client")
  );

  log(selected);

  useEffect(() => {
    setSelected(Object.keys(contacts).map(() => false));
    setUserType(Object.keys(contacts).map(() => "client"));
  }, [contacts]);

  return (
    <div className="container">
      <h3>Contacts</h3>
      {selected.filter((x, i) => x == true).length > 0 ? (
        <>
          <Link
            className="btn btn-primary"
            onClick={async (e) => {
              //Object.keys(contacts).filter((x, i) => selected[i]);
              var data = await API.get("create-room", {});
              if (!data) location.reload();
            }}
          >
            Create new chat
          </Link>
          <button
            style={{ marginLeft: "5px" }}
            className="btn btn-danger"
            onClick={(e) => {
              var newContacts = { ...contacts };
              Object.keys(contacts)
                .filter((x, i) => selected[i])
                .forEach((key) => delete newContacts[key]);
              setContacts(newContacts);
            }}
          >
            Delete
          </button>
        </>
      ) : (
        <></>
      )}
      <ul className="list-group list-group-flush">
        {Object.keys(contacts).map((key, i) => {
          return (
            <li key={key} className="list-group-item d-flex">
              <div className="form-check">
                <input
                  onClick={(e) => {
                    setSelected(
                      selected.map((v, index) =>
                        index != i ? v : !v
                      )
                    );
                  }}
                  readOnly
                  checked={selected[i] ?? false}
                  type="checkbox"
                  className="form-check-input"
                />
              </div>
              {!!selected[i] && (
                <select
                  onChange={(e) =>
                    setUserType(
                      userType.map((v, index) =>
                        index != i ? v : e.target.value
                      )
                    )
                  }
                >
                  <option value="client">client</option>
                  <option value="admin">admin</option>
                  <option value="listen">listen</option>
                </select>
              )}
              <Link
                style={{ marginLeft: "5px" }}
                to={`/contacts/add/${key}`}
                className="link-light link-offset-2 link-underline-opacity-25 link-underline-opacity-100-hover"
              >
                {contacts[key]}
              </Link>
            </li>
          );
        })}
      </ul>
    </div>
  );
}
export default Contacts;
