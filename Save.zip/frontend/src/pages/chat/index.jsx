import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import SendForm from "./send-form";
import Messages from "./messages";

function Chat({ contacts, messages, setMessages }) {
  const { id } = useParams();
  const [chatName, setChatName] = useState("Loading....");

  window.roomID = id;

  if (!messages?.[id]) messages[id] = [];

  useEffect(() => {
    (async () => {
      setChatName(await API.get("chat-name", id));
      var data = await API.get("chat-messages", id);
      if (!data) return;
      setMessages((old) => {
        return {
          ...old,
          [id]: data,
        };
      });
    })();
  }, [id]);

  return (
    <div className="container">
      <center>
        <h3 className="short">{chatName}</h3>
      </center>
      <Messages contacts={contacts} messages={messages?.[id] || []} />
      <SendForm room={id} />
    </div>
  );
}

export default Chat;
