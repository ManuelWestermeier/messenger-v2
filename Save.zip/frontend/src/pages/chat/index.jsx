import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import SendForm from "./send-form";
import Messages from "./messages";

function Chat({ contacts, setContacts }) {
  const { id } = useParams();
  const [chatName, setChatName] = useState("Loading....");
  const [messages, setMessages] = useState({});

  if (!messages?.[id]) messages[id] = [];

  useEffect(() => {
    /*
    API.get("create-room", {
        [user]: "admin",
        EjBqOC7dfQOZuglAcY0BW4kt89o: "user",
      }).then(log);
    */
  }, []);

  useEffect(() => {
    (async () => {
      setChatName(await API.get("chat-name", id));
      var data = await API.get("chat-messages", id);
      if (!data) return;
      setMessages((old) => {
        return {
          ...old,
          [id]: data,
        };
      });
    })();
  }, [id]);

  //if a message come
  API.onSay(
    "incomming-message",
    (data) => {
      setMessages((old) => {
        return {
          ...old,
          [id]: [...old[id], data],
        };
      });
    },
    true
  );

  return (
    <div className="container">
      <h1>{chatName}</h1>
      <Messages  contacts={contacts} setContacts={setContacts}  messages={messages?.[id] || []} />
      <SendForm room={id} />
    </div>
  );
}

export default Chat;
