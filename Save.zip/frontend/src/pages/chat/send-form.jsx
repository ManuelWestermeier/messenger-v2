import { useState } from "react";

function SendForm({ room }) {
  const [messageText, setMessageText] = useState("");
  const [type, setType] = useState("text");
  const [reaction, setReaction] = useState("none");

  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        if (messageText == "") return;
        var data = {
          room,
          data: messageText,
          type,
          reaction,
        };
        API.say("send-message", data);
        setMessageText("");
      }}
      className="send-form"
    >
      <textarea
        name="message"
        title="message"
        value={messageText}
        onChange={(e) => setMessageText(e.target.value)}
        placeholder="Message..."
        className="form-control mb-2"
      ></textarea>
      <button className="btn btn-primary" type="submit" title="send">
        Send
      </button>
    </form>
  );
}
export default SendForm;
