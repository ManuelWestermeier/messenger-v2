import { useEffect, useRef, useState } from "react";

function SendForm({
  room,
  canWrite,
  setCanWrite,
  setSelectedReactionMessagesId,
  selectedReactionMessagesId,
}) {
  const [messageText, setMessageText] = useState("");
  const [type, setType] = useState("text");
  const textarea = useRef();

  window.onfocus = (e) => {
    textarea?.current?.focus?.();
  };

  useEffect(() => {
    API.get("can-send-messages-in-room", room).then(setCanWrite);
  }, [room]);

  function sendMessage() {
    if (messageText == "") return;
    var data = {
      room,
      data: messageText,
      type,
      reaction: selectedReactionMessagesId,
    };
    API.say("send-message", data);
    setMessageText("");
    setSelectedReactionMessagesId("none");
  }

  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        sendMessage();
      }}
      className="send-form"
    >
      <textarea
        name="message"
        title="message"
        value={canWrite ? messageText : "You can't write messages"}
        onChange={(e) => setMessageText(e.target.value)}
        placeholder="Message..."
        className="form-control mb-2"
        ref={textarea}
        onKeyDown={(e) => {
          if (e.key == "Escape") sendMessage();
        }}
      ></textarea>
      <button
        className="btn btn-primary"
        type="submit"
        title="send"
        style={{
          height: "50px",
          width: "50px",
          fill: "white",
        }}
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          height="24"
          viewBox="0 -960 960 960"
          width="24"
        >
          <path d="M120-160v-640l760 320-760 320Zm80-120 474-200-474-200v140l240 60-240 60v140Zm0 0v-400 400Z" />
        </svg>
      </button>
    </form>
  );
}
export default SendForm;
