import { useRef, useState } from "react";

function SendForm({ room }) {
  const [messageText, setMessageText] = useState("");
  const [type, setType] = useState("text");
  const [reaction, setReaction] = useState("none");
  const textarea = useRef();

  window.onfocus = (e) => {
    textarea?.current?.focus?.();
  };

  function sendMessage() {
    if (messageText == "") return;
    var data = {
      room,
      data: messageText,
      type,
      reaction,
    };
    API.say("send-message", data);
    setMessageText("");
  }

  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        sendMessage();
      }}
      className="send-form"
    >
      <textarea
        name="message"
        title="message"
        value={messageText}
        onChange={(e) => setMessageText(e.target.value)}
        placeholder="Message..."
        className="form-control mb-2"
        ref={textarea}
        onKeyDown={(e) => {
          if (e.key == "Escape") sendMessage();
        }}
      ></textarea>
      <button
        className="btn btn-primary"
        type="submit"
        title="send"
        style={{
          height: "50px",
          width: "50px",
          fill: "white",
        }}
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          height="24"
          viewBox="0 -960 960 960"
          width="24"
        >
          <path d="M120-160v-640l760 320-760 320Zm80-120 474-200-474-200v140l240 60-240 60v140Zm0 0v-400 400Z" />
        </svg>
      </button>
    </form>
  );
}
export default SendForm;
