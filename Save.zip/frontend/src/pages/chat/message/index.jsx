import { useState } from "react";
import { Link } from "react-router-dom";
import MessageCommentDropdown from "./message-comment-dropdown";
import Menu from "./menu";

function Message({
  data: { comments, data = "", date, from, id, react, type },
  i,
  contacts,
  room_id,
  canWrite,
  messagesLength,
  lastMsg,
}) {
  const [viewComments, setViewComments] = useState(false);
  return (
    <>
      <div
        onClick={(e) => {
          e.target.scrollIntoView({ behavior: "smooth", block: "center" });
          setViewComments((v) => !v);
        }}
        ref={i == messagesLength - 1 ? lastMsg : null}
        key={id}
        className={[
          "message",
          from == user ? "my" : "other",
          i == messagesLength - 1 ? "msg-anim" : "",
        ].join(" ")}
      >
        <p className="main">
          {data.split(" ").map((word, i) => {
            try {
              new URL(word);
              return (
                <>
                  {" "}
                  <a className="text-white" target="_blank" href={word}>
                    {word}
                  </a>
                </>
              );
            } catch (error) {
              return " " + word;
            }
          })}
        </p>
        <span className="meta">
          <Link
            to={`/contacts/add/${from}`}
            className="link-light link-offset-2 link-underline-opacity-25 link-underline-opacity-100-hover"
          >
            {contacts?.[from] ?? from}
          </Link>{" "}
          <b>{date}</b>
          <Menu
            canWrite={canWrite}
            id={id}
            room_id={room_id}
            setViewComments={setViewComments}
            viewComments={viewComments}
          />
        </span>
      </div>
      {viewComments && (
        <MessageCommentDropdown
          className={[
            "message",
            from == user ? "my" : "other",
            i == messagesLength - 1 ? "msg-anim" : "",
          ].join(" ")}
          comments={comments}
          contacts={contacts}
          id={id}
          room={room_id}
        />
      )}
    </>
  );
}

export default Message;
