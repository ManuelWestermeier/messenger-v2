import { useEffect, useRef } from "react";
import Message from "./message";

function Messages({
  messages = [{ comments, data, date, from, id, react, type }],
  contacts,
  room_id,
  canWrite,
  setSelectedReactionMessagesId,
  selectedReactionMessagesId,
}) {
  var lastMsg = useRef();
  var messageVue = useRef();

  useEffect(() => {
    if (lastMsg.current && messageVue.current) {
      var height = messageVue.current.getBoundingClientRect().height;
      var scrollHeight = messageVue.current.scrollHeight / height;
      var scrollPos = messageVue.current.scrollTop / height;

      if (scrollHeight - scrollPos < 1.5)
        lastMsg.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages]);

  return (
    <div ref={messageVue} className="messages-vue">
      {messages.map((data, i) => {
        return (
          <Message
            selectedReactionMessagesId={selectedReactionMessagesId}
            setSelectedReactionMessagesId={setSelectedReactionMessagesId}
            data={data}
            i={i}
            canWrite={canWrite}
            contacts={contacts}
            messagesLength={messages.length}
            room_id={room_id}
            key={data.id}
            lastMsg={lastMsg}
          />
        );
      })}
    </div>
  );
}

export default Messages;
