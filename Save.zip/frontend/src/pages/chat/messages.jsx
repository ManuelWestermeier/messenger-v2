import { Link } from "react-router-dom";

function Messages({
  messages = [{ comments, data, date, from, id, react, type }],
  contacts,
  setContacts,
}) {
  return (
    <div>
      {messages.map(
        ({ comments, data = "", date, from, id, react, type }, i) => {
          if (type == "text")
            return (
              <div
                key={id}
                className={[
                  "message",
                  from == user ? "my" : "other",
                  i == messages.length - 1 ? "msg-anim" : "",
                ].join(" ")}
              >
                <p className="main">{data}</p>
                <span className="meta">
                  <Link>{comments?.[from] ?? from}</Link>
                  <b> {date}</b>
                </span>
              </div>
            );
        }
      )}
    </div>
  );
}

export default Messages;
