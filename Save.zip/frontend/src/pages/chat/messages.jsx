import { useEffect, useRef } from "react";
import Message from "./message";

function Messages({
  messages = [{ comments, data, date, from, id, react, type }],
  contacts,
  room_id,
  canWrite,
}) {
  var lastMsg = useRef();

  useEffect(() => {
    if (lastMsg.current) lastMsg.current.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  return (
    <div className="messages-vue">
      {messages.map((data, i) => {
        return (
          <Message
            data={data}
            i={i}
            canWrite={canWrite}
            contacts={contacts}
            messagesLength={messages.length}
            room_id={room_id}
            key={data.id}
            lastMsg={lastMsg}
          />
        );
      })}
    </div>
  );
}

export default Messages;
