import { Link } from "react-router-dom";
function Chats({ rooms }) {
  return (
    <div className="container">
      <h3>Chats</h3>
      <ul className="list-group list-group-flush">
        {Object.keys(rooms).map((key) => {
          return (
            <Link className="list-group-item" to={`/chat/${key}`} key={key}>
              <li>
                <span>{rooms[key].name}</span>
                <span
                  className="badge bg-primary rounded-pill"
                  style={{ float: "right" }}
                >
                  {rooms[key].unread}
                </span>
              </li>
            </Link>
          );
        })}
      </ul>
    </div>
  );
}
export default Chats;
