import { Link } from "react-router-dom";
function Chats({ rooms, setRooms }) {
  return (
    <div className="container">
      <h3>Chats</h3>
      <ul className="list-group list-group-flush">
        {Object.keys(rooms).map((key) => {
          return (
            <Link
              onClick={(e) => {
                //set the unread messages to 0
                setRooms((old) => {
                  return {
                    ...old,
                    [key]: {
                      name: old[key].name,
                      unread: 0,
                    },
                  };
                });
              }}
              className="list-group-item"
              to={`/chat/${key}`}
              key={key}
            >
              <li>
                <span>{rooms[key].name}</span>
                {rooms[key].unread > 0 && (
                  <span
                    className="badge bg-primary rounded-pill"
                    style={{ float: "right" }}
                  >
                    {rooms[key].unread}
                  </span>
                )}
              </li>
            </Link>
          );
        })}
      </ul>
    </div>
  );
}
export default Chats;
