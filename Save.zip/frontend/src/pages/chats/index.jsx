function Chats({ contacts = {} }) {
  return (
    <div className="container">
      <h3>Chats</h3>
      <ul className="list-group list-group-flush">
        {Object.keys(contacts).map((key) => {
          return (
            <li key={key} className="list-group-item">
              {}
              <span
                className="badge bg-primary rounded-pill"
                style={{ float: "right" }}
              >
                0
              </span>
            </li>
          );
        })}
      </ul>
    </div>
  );
}
export default Chats;
