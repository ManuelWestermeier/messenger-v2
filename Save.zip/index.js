const { createServer } = require("./WSNET_Framework/_server/index.js");
const { randomBytes } = require("crypto");
const { log } = require("console");
const fs = require("fs");
const port = 8080;

const sockets = new Map()

createServer({ port }, async client => {
    //create the user and aut value
    var user = false;
    //create seccion id
    var id = randomBytes(10).toString("base64url")
    //on auth
    client.onGet("auth", data => {
        //check if the user is auth
        if (auth(data)) {
            //set the user to the sended username
            if (!user) {
                user = data.u
                if (!sockets?.[user]) {
                    sockets[user] = { [id]: client }
                }
                else {
                    sockets[user][id] = client
                }
            }
            //return sucsess
            return true;
        }
        //return error
        else return false;
    });
    //on get the unread messages
    client.onGet("unread-messages", () => {
        if (!user) return
        var data = JSON.parse(fs.readFileSync(`data/user-data/${user}/unread.txt`, "utf-8"))
        fs.writeFileSync(`data/user-data/${user}/unread.txt`, "[]", "utf-8");
        return data
    })
    //on create user
    client.onGet("create_new_user", name => {
        if (!user) return createUser(name + "")
        else return false
    });
    //for getting the name
    client.onGet("user-name", id => {
        if (!user) return
        id += ""
        //create the path
        var namePath = `data/user-data/${securifyPath(id)}/name.txt`
        if (fs.existsSync(namePath)) {
            return fs.readFileSync(namePath, "utf-8")
        }
        else return false
    })
    //to send messages
    client.onSay("send-message", msg => {
        if (!user) return
        if (typeof msg != "object") return
        sendMessage(user, msg)
    })
    //to delete messages
    client.onSay("delete-message", (data) => {
        if (!user) return
        if (!(data instanceof Object)) return
        deleteMessage(data, user)
    })
    //check if the user can send messages
    client.onGet("can-send-messages-in-room", data => {
        if (!user) return false;
        data += ""
        //create the room path
        var roomPath = `data/rooms/${securifyPath(data)}`
        //check if the room exist
        if (!fs.existsSync(roomPath)) {
            return false
        }
        //ckeck if the user is in the room
        var usersInRoom = JSON.parse(fs.readFileSync(`${roomPath}/user.txt`, "utf-8"))
        if (!Object.keys(usersInRoom).includes(user)) {
            return false
        }
        //check if the user cant write
        if (usersInRoom[user] == "listen") {
            return false
        }
        else {
            return true
        }
    })
    //to create a new room
    client.onGet("create-room", (data) => {
        if (!user) return false
        if (!(data instanceof Array)) return false
        const [userInRoom, roomName] = data
        if (!(typeof userInRoom == "object")) return false
        return createRoom(userInRoom, roomName + "")
    })
    //chenge chatt name
    client.onSay("change-chatt-name", data => {
        if (!user) return
        if (!(data instanceof Object)) return
        var room = data?.room + ""
        var newName = data?.name + ""

        //create the room path
        var roomPath = `data/rooms/${securifyPath(room)}`
        //check if the room exist
        if (!fs.existsSync(roomPath)) return
        //ckeck if the user is in the room
        var usersInRoom = JSON.parse(fs.readFileSync(`${roomPath}/user.txt`, "utf-8"))
        if (!Object.keys(usersInRoom).includes(user)) return
        if (usersInRoom[user] == "listen") return
        //return the name
        fs.writeFileSync(`${roomPath}/name.txt`, newName, "utf-8")
    })
    //to get the room name
    client.onGet("chat-name", id => {
        if (!user) return
        id += "";
        //create the room path
        var roomPath = `data/rooms/${securifyPath(id)}`
        //check if the room exist
        if (!fs.existsSync(roomPath)) return "chat do not exist"
        //ckeck if the user is in the room
        var usersInRoom = JSON.parse(fs.readFileSync(`${roomPath}/user.txt`, "utf-8"))
        if (!Object.keys(usersInRoom).includes(user)) return "you are not in the chat"
        //return the name
        return fs.readFileSync(`${roomPath}/name.txt`, "utf-8")
    })
    //to get the room messages
    client.onGet("chat-messages", room => {
        if (!user) return
        room += "";
        //create the room path
        var roomPath = `data/rooms/${securifyPath(room)}`
        //check if the room exist
        if (!fs.existsSync(roomPath)) return false
        //ckeck if the user is in the room
        var usersInRoom = JSON.parse(fs.readFileSync(`${roomPath}/user.txt`, "utf-8"))
        if (!Object.keys(usersInRoom).includes(user)) return false
        //return the name
        var messageIDs = JSON.parse(fs.readFileSync(`${roomPath}/messages.txt`, "utf-8"))
        return messageIDs.map(id => JSON.parse(fs.readFileSync(`${roomPath}/message-data/${id}.txt`), "utf-8"))
    })
    //to comment a message
    client.onSay("comment-message", data => {
        if (!user) return
        if (!(data instanceof Object)) return
        var room = securifyPath(data?.room + "")
        var msgId = securifyPath(data?.id + "")
        var comment = data?.comment + ""
        if (comment.length > 10) return
        var path = `data/rooms/${room}/message-data/${msgId}.txt`
        if (!fs.existsSync(path)) return
        var msg_data = JSON.parse(fs.readFileSync(path, "utf-8"))
        msg_data.comments = {
            ...msg_data.comments,
            [user]: comment,
        }
        if (comment == "")
            delete msg_data.comment?.[user]
        fs.writeFileSync(path, JSON.stringify(msg_data), "utf-8")

        var roomPath = `data/rooms/${securifyPath(room)}`
        //ckeck if the user is in the room
        var usersInRoom = JSON.parse(fs.readFileSync(`${roomPath}/user.txt`, "utf-8"))
        if (!Object.keys(usersInRoom).includes(user)) return

        Object.keys(usersInRoom).forEach(userInRoom => {
            if (sockets?.[userInRoom]) {
                for (var clientID in sockets[userInRoom]) {
                    //send
                    sockets[userInRoom][clientID]?.say?.("comment-message", { room, msgId, comment, user })
                }
            }
            //user insnt online
            else {
                var newUnreadMessages = [
                    ...JSON.parse(fs.readFileSync(`data/user-data/${securifyPath(userInRoom)}/unread.txt`, "utf-8")),
                    {
                        ...data,
                        room: msg.room + ""
                    }
                ]
                fs.writeFileSync(`data/user-data/${securifyPath(userInRoom)}/unread.txt`, JSON.stringify(
                    newUnreadMessages
                ), "utf-8")
            }
        });
    })

    client.onclose = () => close()
    client.onerror = () => close()

    function close() {
        client.close()
        delete client;
        if (!user) return;
        delete sockets?.[user]?.[id]
        if (Object.keys(sockets?.[user] ?? {}).length == 0)
            delete sockets?.[user]
    }

})

function deleteMessage(data, user) {
    var room = data?.room + ""
    var messageID = data?.id + ""
    //create the room path
    var roomPath = `data/rooms/${securifyPath(room)}`
    //check if the room exist
    if (!fs.existsSync(roomPath)) return
    //ckeck if the user is in the room
    var usersInRoom = JSON.parse(fs.readFileSync(`${roomPath}/user.txt`, "utf-8"))
    if (!Object.keys(usersInRoom).includes(user)) return
    //check if the user cant write
    if (usersInRoom[user] == "listen") return
    //store the messages
    //push the message
    var messages = JSON.parse(fs.readFileSync(`${roomPath}/messages.txt`, "utf-8"))
    if (!messages.includes(messageID)) return
    //remove the unused message
    fs.writeFileSync(`${roomPath}/messages.txt`, JSON.stringify(messages.filter(id => id != messageID)), "utf-8")
    //delete the message
    fs.unlinkSync(`${roomPath}/message-data/${messageID}.txt`)
    //create the data
    var data = {
        room,
        id: messageID,
    }
    //send message to all user in room
    Object.keys(usersInRoom).forEach(userInRoom => {
        if (sockets?.[userInRoom]) {
            for (var clientID in sockets[userInRoom]) {
                //send
                sockets[userInRoom][clientID]?.say?.("delete-message", data)
            }
        }
    });
}

function sendMessage(user, msg) {
    //check the params
    if (!msg.room) return
    //create the room path
    var roomPath = `data/rooms/${securifyPath(msg.room + "")}`
    //check if the room exist
    if (!fs.existsSync(roomPath)) return
    //ckeck if the user is in the room
    var usersInRoom = JSON.parse(fs.readFileSync(`${roomPath}/user.txt`, "utf-8"))
    if (!Object.keys(usersInRoom).includes(user)) return
    //check if the user cant write
    if (usersInRoom[user] == "listen") return
    //create the data
    var data = {
        from: user,
        id: randomBytes(10).toString("base64url"),
        data: msg?.data + "" || "",
        type: msg?.type + "" || "text",
        date: new Date().toLocaleString(),
        react: msg?.reaction + "" == "none" ? false : msg?.reaction + "",
        comments: {},
    }
    //send message to all user in room
    Object.keys(usersInRoom).forEach(userInRoom => {
        if (sockets?.[userInRoom]) {
            for (var clientID in sockets[userInRoom]) {
                //send
                sockets[userInRoom][clientID]?.say?.("incomming-message", { ...data, room: msg.room + "" })
            }
        }
        //user insnt online
        else {
            var newUnreadMessages = [
                ...JSON.parse(fs.readFileSync(`data/user-data/${securifyPath(userInRoom)}/unread.txt`, "utf-8")),
                {
                    ...data,
                    room: msg.room + ""
                }
            ]
            fs.writeFileSync(`data/user-data/${securifyPath(userInRoom)}/unread.txt`, JSON.stringify(
                newUnreadMessages
            ), "utf-8")
        }
    });
    //store the messages
    //push the message
    var messages = JSON.parse(fs.readFileSync(`${roomPath}/messages.txt`, "utf-8"))
    messages.push(data.id);
    fs.writeFileSync(`${roomPath}/messages.txt`, JSON.stringify(messages), "utf-8")
    //store the message
    fs.writeFileSync(`${roomPath}/message-data/${data.id}.txt`, JSON.stringify(data), "utf-8")
}

function createRoom(usersInRoom = {}, roomName) {
    //check if all user exist
    if (Object.keys(usersInRoom)
        .map(userID => fs.existsSync(`data/user/${securifyPath(userID + "")}.txt`))
        .includes(false)
    ) return false
    //check if one user is admin
    if (!Object.keys(usersInRoom)
        .map(userID => usersInRoom[userID] == "admin")
        .includes(true)
    ) return false
    //create the id
    var id = securifyPath(randomBytes(30).toString("base64url"))
    //create the room path
    var roomPath = `data/rooms/${id}`
    //check if the room exist
    if (fs.existsSync(roomPath)) return false
    //create the files and folders
    fs.mkdirSync(`${roomPath}/message-data/`, { recursive: true })
    fs.writeFileSync(`${roomPath}/user.txt`, JSON.stringify(usersInRoom), "utf-8")
    fs.writeFileSync(`${roomPath}/messages.txt`, "[]", "utf-8")
    fs.writeFileSync(`${roomPath}/name.txt`, roomName ?? `Room ${id}`, "utf-8")
    fs.writeFileSync(`${roomPath}/description.txt`, "Hello!!\nThis is a new Room", "utf-8")
    fs.writeFileSync(`${roomPath}/logo.txt`, "", "utf-8")
    //send the id back
    return id;
}

//menage authentication
function auth(data) {
    //check if the user and password is set
    if (!data?.u || !data?.p) return false;
    //create the file path
    const userPath = `data/user/${securifyPath(data.u)}.txt`
    //check if the user exists
    if (!fs.existsSync(userPath)) return false;
    //get the password from the user-file
    const password = fs.readFileSync(userPath, "utf-8");
    //return the user-password is equalt to the sended password
    return password == (data?.p + "");

}
//create user
function createUser(name) {
    //create random userdata
    const userData = {
        u: securifyPath(randomBytes(20).toString("base64url")),
        p: randomBytes(40).toString("base64url")
    }
    //create the userfile path
    const userPath = `data/user/${userData.u}.txt`
    //check if the user not exists
    if (fs.existsSync(userPath)) return false;
    //store the password
    fs.writeFileSync(userPath, userData.p, "utf-8");
    //create an new user dir
    fs.mkdirSync(`data/user-data/${userData.u}`, { recursive: true })
    //store the name
    fs.writeFileSync(`data/user-data/${userData.u}/name.txt`, name + "", "utf-8");
    //store the unread messages
    fs.writeFileSync(`data/user-data/${userData.u}/unread.txt`, "[]", "utf-8");

    return userData;

}
//securify paths
function securifyPath(str) {
    return (str + "").split("/").join("_").split(".").join("_");
}

process.on("uncaughtException", err => log(err))