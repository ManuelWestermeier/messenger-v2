import { useEffect, useRef } from "react";
import { Link } from "react-router-dom";

function Messages({
  messages = [{ comments, data, date, from, id, react, type }],
  contacts,
  room_id,
  canWrite,
}) {
  var lastMsg = useRef();

  useEffect(() => {
    if (lastMsg.current) lastMsg.current.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  return (
    <div className="messages-vue">
      {messages.map(
        ({ comments, data = "", date, from, id, react, type }, i) => {
          if (type == "text")
            return (
              <div
                ref={i == messages.length - 1 ? lastMsg : null}
                key={id}
                className={[
                  "message",
                  from == user ? "my" : "other",
                  i == messages.length - 1 ? "msg-anim" : "",
                ].join(" ")}
              >
                <p className="main">{data}</p>
                <span className="meta">
                  <Link
                    to={`/contacts/add/${from}`}
                    className="link-light link-offset-2 link-underline-opacity-25 link-underline-opacity-100-hover"
                  >
                    {contacts?.[from] ?? from}
                  </Link>{" "}
                  <b>{date}</b>
                  <svg
                    style={{ display: !canWrite && "none" }}
                    role="button"
                    className="c-pointer"
                    onClick={(e) => {
                      API.say("delete-message", {
                        room: room_id,
                        id,
                      });
                    }}
                    xmlns="http://www.w3.org/2000/svg"
                    height="24"
                    viewBox="0 -960 960 960"
                    width="24"
                  >
                    <path d="M280-120q-33 0-56.5-23.5T200-200v-520h-40v-80h200v-40h240v40h200v80h-40v520q0 33-23.5 56.5T680-120H280Zm400-600H280v520h400v-520ZM360-280h80v-360h-80v360Zm160 0h80v-360h-80v360ZM280-720v520-520Z" />
                  </svg>
                </span>
              </div>
            );
        }
      )}
    </div>
  );
}

export default Messages;
