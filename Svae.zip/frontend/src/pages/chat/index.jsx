import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import SendForm from "./send-form";
import Messages from "./messages";

function Chat({ contacts, messages, setMessages, setChats }) {
  const { id } = useParams();
  const [chatName, setChatName] = useState("Loading....");
  const [canWrite, setCanWrite] = useState(true);

  window.roomID = id;

  if (!messages?.[id]) messages[id] = [];

  useEffect(() => {
    (async () => {
      var name = await API.get("chat-name", id);
      setChatName(name);
      var data = await API.get("chat-messages", id);
      if (!data) return;
      setMessages((old) => {
        return {
          ...old,
          [id]: data,
        };
      });
      setChats((old) => {
        return {
          ...old,
          [id]: {
            name,
            unread: 0,
          },
        };
      });
    })();
  }, [id]);

  return (
    <div className="container">
      <center>
        <h3>
          <input
            //chenge the chat name
            onInput={(e) => {
              setChatName(e.target.value);
              API.say("change-chatt-name", {
                room: id,
                name: e.target.value,
              });
            }}
            className="short n-input"
            value={chatName}
          />
        </h3>
      </center>
      <Messages
        canWrite={canWrite}
        room_id={id}
        contacts={contacts}
        messages={messages?.[id] || []}
      />
      <SendForm canWrite={canWrite} setCanWrite={setCanWrite} room={id} />
    </div>
  );
}

export default Chat;
